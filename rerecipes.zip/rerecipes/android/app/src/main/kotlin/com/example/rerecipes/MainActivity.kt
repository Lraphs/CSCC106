package com.example.rerecipes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
